package testing;

import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;

import org.junit.jupiter.api.Test;

import weather.WeatherDatum;
import weather.WeatherForecast;
import weather.WeatherObservation;
import weather.WeatherPattern;
import weather.io.WeatherForecastReader;
import weather.io.WeatherObservationReader;

class TestIO
{
  
  @Test
  void testWeatherForecastReader()
  {
    WeatherForecast t1;
    WeatherForecast t2;
    WeatherForecastReader fore;
    InputStream input = TestIO.class.getResourceAsStream("f.txt");
    InputStreamReader inputReader = new InputStreamReader(input);
    WeatherPattern sunny = new WeatherPattern("Sunny");
    WeatherPattern cloudy = new WeatherPattern("Cloudy");
    try (BufferedReader forecastReader = new BufferedReader(inputReader)) {
      forecastReader.mark(5000);
      fore = new WeatherForecastReader(forecastReader);
      fore.addObserver(sunny);
      fore.addObserver(cloudy);
      fore.readOne();
      
      t1 = (WeatherForecast) sunny.getElement(0);
      assertEquals("PWW01,Sunny, +74.2F, +91.3F", t1.toString(),
          "test read one and readWeatherDatum.");
      fore.readAll();
      
      fore.readOne();
      assertEquals(6, sunny.size(),
          "test readOne when equals null");
      
      Iterator<WeatherDatum> it = cloudy.iterator();
      forecastReader.reset();
      String str;
      while(it.hasNext()) {
        str = forecastReader.readLine();
        t2 = (WeatherForecast) it.next();
        assertEquals(str, t2.toString(),
            "test read all and readWeatherDatum.");
      }
      
      fore.removeObserver(cloudy);
      
     } catch (IOException e) {
      e.printStackTrace();
     }
  }

  @Test
  void testObservationReader()
  {
    WeatherObservation t1;
    WeatherObservation t2;
    WeatherObservationReader obs;
    InputStream input = TestIO.class.getResourceAsStream("o.txt");
    InputStreamReader inputReader = new InputStreamReader(input);
    WeatherPattern sunny = new WeatherPattern("Sunny");
    WeatherPattern cloudy = new WeatherPattern("Cloudy");

    try (BufferedReader observationReader = new BufferedReader(inputReader)) {
      observationReader.mark(5000);
      obs = new WeatherObservationReader(observationReader);
      obs.addObserver(sunny);
      obs.addObserver(cloudy);
      obs.readOne();
      
      t1 = (WeatherObservation) sunny.getElement(0);
      assertEquals("PWW01,PartlyCloudy, +85.7F", t1.toString(),
          "test read one and readWeatherDatum.");
      obs.readAll();
      
      obs.readOne();
      assertEquals(6, sunny.size(),
          "test readOne when equals null");
      
      Iterator<WeatherDatum> it = cloudy.iterator();
      observationReader.reset();
      String str;
      while(it.hasNext()) {
        str = observationReader.readLine();
        t2 = (WeatherObservation) it.next();
        assertEquals(str, t2.toString(),
            "test read all and readWeatherDatum.");
      }
      
      obs.removeObserver(cloudy);
     } catch (IOException e) {
      e.printStackTrace();
     }
  }
}
