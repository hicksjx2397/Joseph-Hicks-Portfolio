package weatherbitmaps;

import java.awt.geom.Rectangle2D;


import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;

import app.JApplication;
import gui.WeatherBoard;
import io.ResourceFinder;
import visual.ScaledVisualizationRenderer;
import visual.VisualizationView;
import visual.dynamic.sampled.Screen;
import visual.dynamic.sampled.TransformableContentSuperimposition;
import visual.statik.SimpleContent;
import visual.statik.sampled.ContentFactory;
import weather.WeatherObserver;
import weather.visual.TextContent;

/**
* TextapplicationV2.0 interface.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/12/2023 
*/
public class TextApplicationV2 extends WeatherBitmapsApplication
{
  private WeatherBoard weatherBoard;
  private Screen screen1;
  private final JFrame window  = new JFrame("About WeatherBits");

  /**
   * Value constructor for TextApplicationV2.
   *
   *@param args command-line arguments
   */
  public TextApplicationV2(final String[] args)
  {
    super(args);
    weatherBoard = new WeatherBoard();
  }

  @Override
  protected JComponent getGUIComponent()
  {
    // TODO Auto-generated method stub
    return weatherBoard;
  }
  
 
  @Override
  protected WeatherObserver getWeatherObserver()
  {
    // TODO Auto-generated method stub
    return weatherBoard;
  }
  
  @Override
  protected void handleAbout()
  {
    screen1.start();
    window.setVisible(true);
  }
  
  @Override
  public void init()
  {
    super.init();
    TransformableContentSuperimposition content = 
        new TransformableContentSuperimposition(new TextContent("TextApplicationV2.0",
            new Rectangle2D.Double(0,0, 100, 100), 60, 100), 12, 13, 100);
    ResourceFinder finder = ResourceFinder.createInstance(new resources.Marker());
    screen1 = new Screen(6);
    //screen1.setRepeating(true);
    VisualizationView view1 = screen1.getView();
    view1.setRenderer(new ScaledVisualizationRenderer(view1.getRenderer(),
        300.0, 300.0));
    view1.setBounds(0,0,100,100);
    String[] names = finder.loadResourceNames("vortex.txt");
    ContentFactory factory = new ContentFactory(finder);
    SimpleContent[] frames1 = factory.createContents(names, 4);
    for (int i=0; i<frames1.length; i++)
    {
      screen1.add(frames1[i]);
    }
    
    JPanel contentPane = (JPanel)window.getContentPane();
    window.setSize((WIDTH * 2)/3, (HEIGHT * 1)/2);
    contentPane.setBounds(0,0,100,100);
    screen1.addSuperimposition(content);
    contentPane.add(view1);
  }
  
  /**
   * Main method for running app.
   *
   *@param args command-line arguments
   */
  public static void main(final String[] args)
  {
    JApplication app = new TextApplicationV2(args);
    invokeInEventDispatchThread(app);
  }

}
