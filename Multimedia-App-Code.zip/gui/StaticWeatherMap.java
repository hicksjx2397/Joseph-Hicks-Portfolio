package gui;

import java.awt.Color;

import java.awt.Image;
import java.awt.color.ColorSpace;
import java.awt.geom.Point2D;
import java.awt.image.ColorConvertOp;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import io.ResourceFinder;
import map.io.BaseMapReader;
import map.io.StationLocationReader;
import resources.Marker;
import visual.VisualizationView;
import visual.statik.sampled.Content;
import visual.statik.sampled.ContentFactory;
import weather.WeatherDatum;
import weather.WeatherObserver;
import weather.visual.WeatherDatumContent;
import weather.visual.WeatherDatumContentFactory;
import weather.visual.WeatherIconReader;

/**
* staticWeatherMap object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/22/2023 
*/
public class StaticWeatherMap extends visual.Visualization implements WeatherObserver
{
  private static Color BACKGROUND_COLOR = new Color(204, 204, 255);
  private Content watermark;
  private WeatherDatumContentFactory factory;
  private List<WeatherDatumContent> currentContent;
  private boolean isRed;
  
  /**
   * Explicit values constructor.
   *
   *@param useWatermark watermark to use
   *@param grayWatermark grey watermark
   *@param width of map
   *@param height of map
   * @throws IOException 
   */
  public StaticWeatherMap(final String useWatermark, final String grayWatermark, 
      final int width, final int height)
  {
    super();
    this.currentContent = new LinkedList<WeatherDatumContent>();
    this.isRed = false;
    ResourceFinder jarFinder = ResourceFinder.createInstance(new Marker());
    VisualizationView view = getView();
    view.setBackground(BACKGROUND_COLOR);
    view.setBounds(0, 0, width, height);
    view.setSize(width, height);

    
    if (useWatermark != null)
    {
      // display water mark
      ContentFactory contentFactory = new ContentFactory(jarFinder);
      watermark = contentFactory.createContent("logoWeatherBits.png", 4);
      watermark.setLocation(width / 4, height - (watermark.getBounds2D().getHeight() * 1.5));
      
      if (grayWatermark != null)
      {
        // grey out water mark
        ColorSpace cs = ColorSpace.getInstance(ColorSpace.CS_GRAY);  
        ColorConvertOp op = new ColorConvertOp(cs, null);
        watermark.setBufferedImageOp(op);
        
        
      }
      
      add(watermark);
    }
    //create map outline
    visual.statik.described.Content map = null;
    BaseMapReader poly = new BaseMapReader(jarFinder);
    try
    {
      map = poly.read("harrisonburg.map", new Color(0,0,0), new Color(255,255,255));
    }
    catch (IOException e)
    {
      // TODO Auto-generated catch block
      JOptionPane.showMessageDialog(null, "Failed to read in map locations.");
    }
    //read in icons;
    WeatherIconReader reader = new WeatherIconReader(jarFinder);
    Map<String, Image> images = null;
    try
    {
      images = reader.read();
    }
    catch (IOException e)
    {
      // TODO Auto-generated catch block
      JOptionPane.showMessageDialog(null, "Failed to load icons.");
    }
      
    //read in station locations.
    StationLocationReader stationLocReader = new StationLocationReader(jarFinder);
    Map<String, Point2D> locs = null;
    try
    {
      locs = stationLocReader.read("stations.loc");
    }
    catch (IOException e)
    {
      // TODO Auto-generated catch block
      JOptionPane.showMessageDialog(null, "Failed to load station locations.");
    }
    factory = new WeatherDatumContentFactory(locs, images);
    add(map);
  }

  @Override
  public void reset()
  {
    // TODO Auto-generated method stub
    if (!currentContent.isEmpty())
    {
      Iterator<WeatherDatumContent> it = this.currentContent.iterator();
      while (it.hasNext())
      {
        remove(it.next());
      }
      this.currentContent.clear();
    }
    if (isRed)
    {
      isRed = false;
    } else 
    {
      isRed = true;
    }
    
  }

  @Override
  public void handleWeatherDatum(final WeatherDatum datum)
  {
    Color color = null;
    if (isRed)
    {
      color = new Color(255,0,0);
    } else
    {
      color = new Color(0,0,255);
    }
    WeatherDatumContent con = factory.createContent(datum, color);
    this.currentContent.add(con);
    add(con);
  }
}
