var numOne = document.getElementById('num-one');
var numTwo = document.getElementById('num-two');
var operator = document.getElementById('operator');
var sum = document.getElementById('sum');

numOne.addEventListener('input', math);
numTwo.addEventListener('input', math);
operator.addEventListener('input', math);

function math() {
var one = parseFloat(numOne.value) || 0;
var two = parseFloat(numTwo.value) || 0;

switch (operator.value) {
    case "+":
      resultNum = one + two;
      break;

    case "-":
      resultNum = one - two;
      break;

    case "*":
      resultNum = one * two;
      break;

    case "/":
      resultNum = one / two;
      break;

      default:
        resultNum = 0;
    }

sum.innerText = "Answer: " + resultNum;
}