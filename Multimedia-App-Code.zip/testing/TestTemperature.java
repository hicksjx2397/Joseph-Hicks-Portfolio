package testing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

import measurement.Scale;
import measurement.Temperature;

class TestTemperature
{

  @Test
  void defaultConstructor() 
  {
    Temperature t = new Temperature();
    assertEquals("  +0.0F", t.toString(), "Check default constructor or toString()");
  }

  @Test
  void constructorDouble() 
  {
    Temperature t = new Temperature(57.9);
    assertEquals(" +57.9F", t.toString(), "Temperature(double)");

    t = new Temperature(108.1);
    assertEquals("+108.1F", t.toString(), "Temperature(double)");
    
    t = new Temperature(-19.2);
    assertEquals(" -19.2F", t.toString(), "Temperature(double)");
  }

  @Test
  void constructorDoubleScale() 
  {
    Temperature t = new Temperature(57.9, Scale.F);
    assertEquals(" +57.9F", t.toString(), "Temperature(double,Scale)");

    t = new Temperature(108.1, Scale.F);
    assertEquals("+108.1F", t.toString(), "Temperature(double,Scale)");
    
    t = new Temperature(-19.2, Scale.F);
    assertEquals(" -19.2F", t.toString(), "Temperature(double,Scale)");
    
    t = new Temperature(38.1, Scale.C);
    assertEquals(" +38.1C", t.toString(), "Temperature(double,Scale)");
    
    t = new Temperature(-19.1, Scale.C);
    assertEquals(" -19.1C", t.toString(), "Temperature(double,Scale)");

    t = new Temperature(108.1, (Scale)null);
    assertEquals("+108.1F", t.toString(), "Temperature(double,null)");

    t = new Temperature(108.1, (String)null);
    assertEquals("+108.1F", t.toString(), "Temperature(double,null)");
  }

  @Test
  void constructorDoubleString() 
  {
    Temperature t = new Temperature(57.9, "F");
    assertEquals(" +57.9F", t.toString(), "Temperature(double,String)");

    t = new Temperature(108.1, "F");
    assertEquals("+108.1F", t.toString(), "Temperature(double,String)");
    
    t = new Temperature(-19.2, "F");
    assertEquals(" -19.2F", t.toString(), "Temperature(double,String)");
    
    t = new Temperature(38.1, "C");
    assertEquals(" +38.1C", t.toString(), "Temperature(double,String)");
    
    t = new Temperature(-19.1, "C");
    assertEquals(" -19.1C", t.toString(), "Temperature(double,String)");
  }

  @Test
  void constructorTemperature() 
  {
    Temperature t = new Temperature(57.9, "F");
    Temperature s = new Temperature(t);
    assertEquals(" +57.9F", s.toString(), "Temperature(Temperature)");

    t = new Temperature(38.1, "C");
    s = new Temperature(t);
    assertEquals(" +38.1C", s.toString(), "Temperature(double,String)");
  }
  
  @Test
  void toStringTemp()
  {
    Temperature t = new Temperature(212.0, "F");
    assertEquals("+212.0F", t.toString(), "toString()");
    assertEquals("+212.0F", t.toString(), "toString(Scale.F)");
    assertEquals("+100.0C", t.toString(Scale.C), "toString(Scale.C)");
    
    Temperature s = new Temperature(0.0, "C");
    assertEquals("  +0.0C", s.toString(), "toString()");
    assertEquals("  +0.0C", s.toString(), "toString(Scale.C)");
    assertEquals(" +32.0F", s.toString(Scale.F), "toString(Scale.F)");
    
    
  }
  
  @Test
  void fromStringVALID()
  {
    Temperature t = new Temperature(57.9, "F");
    t.fromString(" +38.1C");
    assertEquals(" +38.1C", t.toString());
    
    t.fromString(" -19.1C");
    assertEquals(" -19.1C", t.toString());

    t.fromString("  +0.0F");
    assertEquals("  +0.0F", t.toString());
    
    t.fromString(" +38.1f");
    assertEquals(" +38.1F", t.toString());
  }
  
  @Test
  void fromStringINVALID()
  {
    Temperature t = new Temperature(57.9, "F");

    t.fromString(" +5A.9F");
    assertEquals(" +57.9F", t.toString(), "Alphabetic");
    
    t.fromString("+57.9F");
    assertEquals(" +57.9F", t.toString(), "Field Width");

    t.fromString("  57.9F");
    assertEquals(" +57.9F", t.toString(), "No Sign");

    t.fromString(" -57.9a");
    assertEquals(" +57.9F", t.toString(), "Invalid Scale");
}
  
  @Test
  void parseTemperatureVALID()
  {
    Temperature t;
    t = Temperature.parseTemperature(" +38.1C");
    assertEquals(" +38.1C", t.toString());
    
    t = Temperature.parseTemperature(" -19.1C");
    assertEquals(" -19.1C", t.toString());

    t = Temperature.parseTemperature("  +0.0F");
    assertEquals("  +0.0F", t.toString());
    
    t = Temperature.parseTemperature(" +38.1f");
    assertEquals(" +38.1F", t.toString());
  }
  
  @Test
  void parseTemperatureINVALID()
  {
    Temperature t;

    t = Temperature.parseTemperature(" +5A.9F");
    assertEquals("  +0.0F", t.toString(), "Alphabetic");
    
    t = Temperature.parseTemperature("+57.9F");
    assertEquals("  +0.0F", t.toString(), "Field Width");

    t = Temperature.parseTemperature("  57.9F");
    assertEquals("  +0.0F", t.toString(), "No Sign");

    t = Temperature.parseTemperature(" -57.9a");
    assertEquals("  +0.0F", t.toString(), "Invalid Scale");
}

  @Test
  void compareTo()
  {
    Temperature[] temps = new Temperature[6];
    temps[0] = new Temperature(100.0, "C");
    temps[1] = new Temperature(190.0, "F");
    temps[2] = new Temperature( 32.0, "F");
    temps[3] = new Temperature( 80.0, "F");
    temps[4] = new Temperature(-20.0, "F");
    temps[5] = new Temperature(  0.0, "C");

    Arrays.sort(temps);
    
    assertEquals(" -20.0F", temps[0].toString(Scale.F));
    assertEquals(" +32.0F", temps[1].toString(Scale.F));
    assertEquals(" +32.0F", temps[2].toString(Scale.F));
    assertEquals(" +80.0F", temps[3].toString(Scale.F));
    assertEquals("+190.0F", temps[4].toString(Scale.F));
    assertEquals("+212.0F", temps[5].toString(Scale.F));
  }

  @Test
  void increaseBy()
  {
    Temperature pf, nf, pc, nc;
    
    pf = new Temperature(100.0, "F");
    nf = new Temperature(-50.0, "F");
    pc = new Temperature(100.0, "C");
    nc = new Temperature(-20.0, "C");
    
    pf = new Temperature(100.0, "F");
    pf.increaseBy(pf);
    assertEquals("+200.0F", pf.toString(Scale.F), "positive F");
    
    pf = new Temperature(100.0, "F");
    pf.increaseBy(nf);
    assertEquals(" +50.0F", pf.toString(Scale.F),  "negative F");
    assertEquals(" -50.0F", nf.toString(Scale.F),  "Side Effects");
    
    pf = new Temperature(100.0, "F");
    pf.increaseBy(pc);
    assertEquals("+312.0F", pf.toString(Scale.F),  "positive C");
    assertEquals("+212.0F", pc.toString(Scale.F),  "Side Effects");
    
    pf = new Temperature(100.0, "F");
    pf.increaseBy(nc);
    assertEquals(" +96.0F", pf.toString(Scale.F),  "negative C");

    
    pf = new Temperature(100.0, "F");
    nf = new Temperature(-50.0, "F");
    pc = new Temperature(100.0, "C");
    nc = new Temperature(-20.0, "C");
    
    nf = new Temperature(-50.0, "F");
    nf.increaseBy(pf);
    assertEquals(" +50.0F", nf.toString(Scale.F), "positive F");
    
    nf = new Temperature(-50.0, "F");
    nf.increaseBy(nf);
    assertEquals("-100.0F", nf.toString(Scale.F),  "negative F");
    
    nf = new Temperature(-50.0, "F");
    nf.increaseBy(pc);
    assertEquals("+162.0F", nf.toString(Scale.F),  "positive C");
    
    nf = new Temperature(-50.0, "F");
    nf.increaseBy(nc);
    assertEquals(" -54.0F", nf.toString(Scale.F),  "negative C");
  }

  @Test
  void decreaseBy()
  {
    Temperature pf, nf, pc, nc;
    
    pf = new Temperature(100.0, "F");
    nf = new Temperature(-50.0, "F");
    pc = new Temperature(100.0, "C");
    nc = new Temperature(-20.0, "C");
    
    pf = new Temperature(100.0, "F");
    pf.decreaseBy(pf);
    assertEquals("  +0.0F", pf.toString(Scale.F), "positive F");
    
    pf = new Temperature(100.0, "F");
    pf.decreaseBy(nf);
    assertEquals("+150.0F", pf.toString(Scale.F),  "negative F");
    assertEquals(" -50.0F", nf.toString(Scale.F),  "Side Effects");
    
    pf = new Temperature(100.0, "F");
    pf.decreaseBy(pc);
    assertEquals("-112.0F", pf.toString(Scale.F),  "positive C");
    assertEquals("+212.0F", pc.toString(Scale.F),  "Side Effects");
    
    pf = new Temperature(100.0, "F");
    pf.decreaseBy(nc);
    assertEquals("+104.0F", pf.toString(Scale.F),  "negative C");

    
    pf = new Temperature(100.0, "F");
    nf = new Temperature(-50.0, "F");
    pc = new Temperature(100.0, "C");
    nc = new Temperature(-20.0, "C");
    
    nf = new Temperature(-50.0, "F");
    nf.decreaseBy(pf);
    assertEquals("-150.0F", nf.toString(Scale.F), "positive F");
    
    nf = new Temperature(-50.0, "F");
    nf.decreaseBy(nf);
    assertEquals("  +0.0F", nf.toString(Scale.F),  "negative F");
    
    nf = new Temperature(-50.0, "F");
    nf.decreaseBy(pc);
    assertEquals("-262.0F", nf.toString(Scale.F),  "positive C");
    
    nf = new Temperature(-50.0, "F");
    nf.decreaseBy(nc);
    assertEquals(" -46.0F", nf.toString(Scale.F),  "negative C");
  }

}
