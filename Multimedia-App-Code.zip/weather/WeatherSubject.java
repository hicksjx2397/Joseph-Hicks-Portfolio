package weather;
/**
* WeatherSubject interface.
*
* @author  Joseph Hicks
* @version 1.0
* @since   1/31/2023 
*/
public interface WeatherSubject
{
  /**
  * Add weather observer.
  *
  * @param observer to add.
  */
  public void addObserver(final WeatherObserver observer);
  
  /**
  * notify all observers.
  *
  * @param weather to change.
  */
  public void notifyObservers(final WeatherDatum weather);
  
  /**
  * Remove weather observer.
  *
  * @param observer to remove.
  */
  public void removeObserver(final WeatherObserver observer);
}
