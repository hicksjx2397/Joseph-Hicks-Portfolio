package weather;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
* Encapsulation of a WeatherPattern" object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   1/31/2023 
*/
public class WeatherPattern implements WeatherObserver, java.lang.Iterable<WeatherDatum>
{
  protected String description;
  protected List<WeatherDatum> data;
  
  /**
  * Default constructor for a weather pattern object.
  *
  * @param description of pattern.
  */
  public WeatherPattern(final String description)
  {
    this.description = description;
    this.data = new ArrayList<WeatherDatum>();
  }

  /**
   * Standard getter.
   *
   *@return description.
   */
  public String getDescription()
  {
    return description; 
  }
  
  /**
   * Get element at a given index.
   *
   * @param index of the datum.
   * @return datum at index.
   */
  public WeatherDatum getElement(final int index)
  {
    return this.data.get(index);
  }
  
  @Override
  public void reset()
  {
    this.data.removeAll(data);
  }

  @Override
  public void handleWeatherDatum(final WeatherDatum datum)
  {
    if (datum != null)
    {
      data.add(datum);
    }
    
  }
  
  /**
   * Standard iterator.
   *
   * @return iterator for list.
   */
  public Iterator<WeatherDatum> iterator()
  {
    return data.iterator();
  }
  
  /**
   * Get the size of weather datum list.
   *
   * @return size of data.
   */
  public int size()
  {
    return data.size();
  }
}
