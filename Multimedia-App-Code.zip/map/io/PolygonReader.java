package map.io;

import java.awt.Shape;
import java.awt.geom.Path2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;
import io.ResourceFinder;

/**
* polygonReader object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/22/2023 
*/
public class PolygonReader
{
  private ResourceFinder finder;
  
  /**
  * Default constructor.
  *
  */
  public PolygonReader()
  {
    this.finder = null;
  }
  
  /**
  * Explicit constructor with reader.
  *
  *@param finder resource to find
  */
  public PolygonReader(final ResourceFinder finder)
  {
    this.finder = finder;
  }
   
  /**
  * read a polygon from either the resource (if the finder attribute is non-null)
  * or the file (if the finder attribute is null) with the given name.
  *
  *@param name of resource or folder
  *@return polygon
  */
  public Shape read(final String name) throws IOException
  {
    Scanner myReader = null;
    if (this.finder != null)
    {
      InputStream is = finder.findInputStream(name);
      BufferedReader in = new BufferedReader(new InputStreamReader(is));
      myReader = new Scanner(in);
    } else
    {
      File myObj = new File(name);
      myReader = new Scanner(myObj);
    }
    Path2D.Float poly = new Path2D.Float();
    
    while(myReader.hasNext())
    {
      String[] line = myReader.nextLine().split(",", 5);
      if (line[0].equals("5"))
      {
        poly.lineTo(Double.parseDouble(line[1]), Double.parseDouble(line[2]));
      } else if (line[0].equals("4")) 
      {
        poly.moveTo(Double.parseDouble(line[1]), Double.parseDouble(line[2]));
      }
      
    }
    poly.closePath();
    myReader.close();
    return poly;
     
  }
  
}
