package testing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Iterator;

import org.junit.jupiter.api.Test;

import weather.WeatherDatum;
import weather.WeatherForecast;
import weather.WeatherPattern;

class TestWeatherPattern
{

  @Test
  void testConstructor()
  {
    WeatherPattern pattern = new WeatherPattern("Unknown");
    assertEquals("Unknown", pattern.getDescription(),
        "get description");
  }

  @Test
  void testData()
  {
    String str = "PWW01,Sunny, +74.2F, +91.3F";
    WeatherPattern pattern = new WeatherPattern("Unknown");
    pattern.handleWeatherDatum(null);
    
    assertEquals(0, pattern.size(),
        "test null element in handleWeatherDatum");
    
    pattern.handleWeatherDatum(WeatherForecast.parseWeatherForecast(str));
    
    assertEquals(1, pattern.size(),
        "test size");
    assertEquals(str, pattern.getElement(0).toString(),
        "test getElement");
    
    Iterator<WeatherDatum> it = pattern.iterator();
    WeatherForecast forecast = (WeatherForecast) it.next();
    assertEquals(str, forecast.toString(),
        "test Iterator");
    
    pattern.reset();
    assertEquals(0, pattern.size(),
        "test reset");
    
  }
}
