package map.io;
import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import io.ResourceFinder;
/**
* stationLocationReader object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/22/2023 
*/

public class StationLocationReader
{
  private ResourceFinder finder;

  /**
  * Explicit constructor with reader.
  *
  *@param finder resource to find
  */
  public StationLocationReader(final ResourceFinder finder)
  {
    this.finder = finder;
  }
     
  /**
  * use the finder attribute to read information about a collection of
  *  weather stations from a geographic location file.
  *
  *@param name of resource or folder
  *@return polygon
  */
  public Map<String, Point2D> read(final String name) throws IOException
  {
    String line = "";
    Map<String, Point2D> map = new HashMap<String, Point2D>();
    InputStream is = finder.findInputStream(name);
    BufferedReader in = new BufferedReader(new InputStreamReader(is));
    Scanner myReader = new Scanner(in);
    while (myReader.hasNextLine())
    {
      line =  myReader.nextLine();
      String[] arr = line.split(",", 5);
      Point2D p = new Point2D.Double();
      p.setLocation(Double.parseDouble(arr[1]), Double.parseDouble(arr[2]));
      map.put(arr[0], p);
    }
    myReader.close();
    return map;
       
  }
}
