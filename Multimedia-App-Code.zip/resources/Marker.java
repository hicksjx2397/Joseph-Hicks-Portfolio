package resources;

/**
* Marker.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/12/2023 
*/
public class Marker
{

}
