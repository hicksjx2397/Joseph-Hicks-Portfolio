package weather.io;

import java.io.BufferedReader;
import java.io.IOException;

import weather.WeatherDatum;
import weather.WeatherObservation;

/**
* Encapsulation of a WeatherObservationReader" object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   1/31/2023 
*/
public class WeatherObservationReader extends WeatherDatumReader
{
  
  /**
   * Explicit value Constructor.
   * @param reader to take observation from.
   */
  public WeatherObservationReader(final BufferedReader reader)
  {
    super(reader);
  }

  @Override
  protected WeatherDatum readWeatherDatum() throws IOException
  {
    String next = this.reader.readLine();
    if (next == null)
    {
      return null;
    }
    return WeatherObservation.parseWeatherObservation(next);
  }
}
