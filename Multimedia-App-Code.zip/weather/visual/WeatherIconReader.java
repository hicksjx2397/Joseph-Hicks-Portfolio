package weather.visual;

import java.awt.Image;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import java.util.HashMap;
import io.ResourceFinder;

/**
* WeatherIconReader object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/22/2023 
*/
public class WeatherIconReader
{
  private static String[] IMAGE_NAMES = {"PartlyCloudy", "Rainy", "Snowy", "Sunny"};
  private ResourceFinder finder;
  
  /**
   * Explicit value constructor.
   *
   *@param finder for resource
   */
  public WeatherIconReader(final ResourceFinder finder)
  {
    this.finder = finder;
  }
  
  /**
   * Must use the finder attribute to read information about a collection of icons.
   * The key in the Map must be the weather condition.
   *
   *@return read location.
   */
  public Map<String, Image> read() throws IOException
  {
    Map<String, Image> images = new HashMap<String, Image>();
    //ImageFactory factory = new ImageFactory();
    
    Image image;
    for (int i = 0; i < IMAGE_NAMES.length; i++)
    {
      String name = IMAGE_NAMES[i];
      image = null;
      try
      {
        InputStream is = finder.findInputStream(name + ".png");
        if (is != null)
        {
          image = ImageIO.read(is);
          is.close();
        }
      }
      catch (IOException io)
      {
        JOptionPane.showMessageDialog(null, "Failed to load icons.");
      // image will be null
      }

      images.put(name, image);
    }
    return images;
  }
}
