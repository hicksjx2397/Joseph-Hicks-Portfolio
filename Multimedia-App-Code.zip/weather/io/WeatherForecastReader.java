package weather.io;

import java.io.BufferedReader;
import java.io.IOException;

import weather.WeatherDatum;
import weather.WeatherForecast;

/**
* Encapsulation of a WeatherForecastReader" object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   1/31/2023 
*/
public class WeatherForecastReader extends WeatherDatumReader
{
  
  /**
   * Explicit value Constructor.
   * @param reader to take forecast from.
   */
  public WeatherForecastReader(final BufferedReader reader)
  {
    super(reader);
  }
  
  @Override
  protected WeatherDatum readWeatherDatum() throws IOException
  {
    String next = this.reader.readLine();
    if (next == null)
    {
      return null;
    }
    return WeatherForecast.parseWeatherForecast(next);
  }

}
