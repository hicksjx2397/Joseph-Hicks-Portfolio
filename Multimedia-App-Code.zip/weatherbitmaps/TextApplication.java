package weatherbitmaps;

import javax.swing.JComponent;
import app.JApplication;
import gui.WeatherBoard;
import weather.WeatherObserver;

/**
* Textapplication interface.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/12/2023 
*/
public class TextApplication extends WeatherBitmapsApplication
{
  WeatherBoard weatherBoard;

  /**
   * Value constructor for TextApplication.
   *
   *@param args command-line arguments
   */
  public TextApplication(final String[] args)
  {
    super(args);
    weatherBoard = new WeatherBoard();
  }

  @Override
  protected JComponent getGUIComponent()
  {
    // TODO Auto-generated method stub
    return weatherBoard;
  }
  
 
  @Override
  protected WeatherObserver getWeatherObserver()
  {
    // TODO Auto-generated method stub
    return weatherBoard;
  }
  
  /**
   * Main method for running app.
   *
   *@param args command-line arguments
   */
  public static void main(final String[] args)
  {
    JApplication app = new TextApplication(args);
    invokeInEventDispatchThread(app);
  }

}
