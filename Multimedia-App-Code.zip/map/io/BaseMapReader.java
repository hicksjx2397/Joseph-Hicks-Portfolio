package map.io;

import java.awt.Color;
import java.awt.Shape;
import java.io.IOException;
import io.ResourceFinder;
import visual.statik.described.Content;

/**
* baseMapReader object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/22/2023 
*/
public class BaseMapReader
{
  PolygonReader reader;
  
  /**
   * Explicit constructor with reader.
   *
   *@param finder resource to find
   */
  public BaseMapReader(final ResourceFinder finder)
  {
    this.reader = new PolygonReader(finder);
  }
  
  /**
   * use the reader attribute to read a polygon and construct 
   * a Content object with the appropriate properties.
   *
   *@param name of file.
   *@param boundary color of the shape.
   *@param interior color.
   *@return content object with the appropriate properties.
   */
  public Content read(final String name, final Color boundary, final Color interior) 
      throws IOException
  {
    //Still need to finish.
    Shape poly = this.reader.read(name);
    Content content = new Content();
    content.setShape(poly);
    content.setPaint(interior);
    content.setColor(boundary);
    
    return content;
  }
}
