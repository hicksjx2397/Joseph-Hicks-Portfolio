package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import measurement.Temperature;
import weather.WeatherForecast;
import weather.WeatherObservation;

class TestWeatherObservation
{

  @Test
  void defaultConstructor() 
  {
    WeatherObservation o  = new WeatherObservation();
    assertEquals("XXX,Unknown,  +0.0F", o.toString(false),
        "Check default constructor or toString()");
  }
  
  @Test
  void valuesConstructor() 
  {
    Temperature t1 = new Temperature(45.9);
    WeatherObservation o  = new WeatherObservation("Virginia", "Cloudy", t1);
    assertEquals("Virginia,Cloudy, +45.9F", o.toString(false),
        "Check valued constructor or toString()");
    assertEquals(" +45.9F", o.getTemperature().toString(), "test gettemp");
  }
  

  @Test
  void toStringVerbose() 
  {
    WeatherObservation o  = new WeatherObservation("PWW02", "Sunny", new Temperature(86.7));
    assertEquals("Location: PWW02\tCondition: Sunny\tTemperature:  +86.7F", 
        o.toString(true), "toString(true)");
  }
  
  @Test
  void fromStringValid() 
  {
    WeatherObservation o  = new WeatherObservation();
    o.fromString("Virginia,Sunny, +79.9F");
    assertEquals("Location: Virginia\tCondition: Sunny\tTemperature:  +79.9F", 
        o.toString(true), "fromString");
  }
  
  @Test
  void fromStringInvalid() 
  {
    WeatherObservation o  = new WeatherObservation();
    assertEquals(null, o.fromString(""));
    assertEquals(null, o.fromString("California,"));
    assertEquals(null, o.fromString("Virginia,Sunny"));
    
    assertEquals("Location: Virginia\tCondition: Sunny\tTemperature:   +0.0F",
        o.toString(true), "fromString no temps");
    o.fromString("Virginia,Sunny, +45.9F, +5A.2F");
    assertEquals("Location: Virginia\tCondition: Sunny\tTemperature:  +45.9F",
        o.toString(true), "fromString invalid temp");
    
  }
  
  @Test
  void parseWeatherObservationTest() 
  {
    WeatherObservation o  = WeatherObservation.parseWeatherObservation("Texas,Rainy,  -5.0C");
    assertEquals("Location: Texas\tCondition: Rainy\tTemperature:   -5.0C",
        o.toString(true), "ParseWeatherObservation");
  }

}
