package weatherbitmaps;

import javax.swing.JComponent;

import app.JApplication;
import gui.DynamicWeatherMap;
import weather.WeatherObserver;

/**
* ApplicationRunner.
*
* @author  Joseph Hicks
* @version 1.0
* @since   3/24/2023 
*/

public class DynamicMapApplication extends WeatherBitmapsApplication
{
  DynamicWeatherMap weatherMap;
  
  /**
   * Value constructor for DynamicMapApplication.
   *
   *@param args command-line arguments
   */
  public DynamicMapApplication(final String[] args)
  {
    super(args);
    if (args.length == 0)
    {
      this.weatherMap = new DynamicWeatherMap(null, null, WIDTH, HEIGHT - 100);
    } else if (args.length == 1)
    {
      this.weatherMap = new DynamicWeatherMap(args[0], null, WIDTH, HEIGHT - 100);
    } else
    {
      this.weatherMap = new DynamicWeatherMap(args[0], args[1], WIDTH, HEIGHT - 100);
    }
    // TODO Auto-generated constructor stub
  }

  @Override
  protected JComponent getGUIComponent()
  {
    // TODO Auto-generated method stub
    return this.weatherMap.getView();
  }

  @Override
  protected WeatherObserver getWeatherObserver()
  {
    // TODO Auto-generated method stub
    return this.weatherMap;
  }
  
  /**
   * Main method for running app.
   *
   *@param args command-line arguments
   */
  public static void main(final String[] args)
  {
    JApplication app = new DynamicMapApplication(args);
    invokeInEventDispatchThread(app);
    
  }

}
