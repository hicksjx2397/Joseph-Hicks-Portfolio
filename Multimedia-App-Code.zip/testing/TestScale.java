package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import measurement.Scale;

class TestScale
{

  @Test
  void toStringScale()
  {
    assertEquals("C", Scale.C.toString(false), "Scale.C.toString(false)");
    assertEquals("F", Scale.F.toString(), "Scale.F.toString()");
  }

  @Test
  void toStringVERBOSE() 
  {
    assertEquals("Celsius", Scale.C.toString(true), "Scale.C.toString(true)");
    assertEquals("Fahrenheit", Scale.F.toString(true), "Scale.F.toString(true)");
  }
  
  @Test
  void parseScaleVALID() 
  {
    assertSame(Scale.F, Scale.parseScale("F"));
    assertSame(Scale.F, Scale.parseScale("f"));
    assertSame(Scale.F, Scale.parseScale("fAHrEnHEiT"));

    assertSame(Scale.C, Scale.parseScale("C"));
    assertSame(Scale.C, Scale.parseScale("c"));
    assertSame(Scale.C, Scale.parseScale("CelSiUs"));
  }
  
  @Test
  void parseScaleINVALID() 
  {
    assertNull(Scale.parseScale("K"));
    assertNull(Scale.parseScale("CelsiusAndThenSome"));
    assertNull(Scale.parseScale("FahrenheitAndThenSome"));
    
    assertNull(Scale.parseScale(null));
  }

}
