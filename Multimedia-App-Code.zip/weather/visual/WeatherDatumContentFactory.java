package weather.visual;

import java.awt.Color;
import java.awt.Image;
import java.awt.geom.Point2D;
import java.util.Map;

import weather.WeatherDatum;

/**
* WeatherDatumContentFactory object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/22/2023 
*/
public class WeatherDatumContentFactory
{
  private Map<String, Image> images;
  private Map<String, Point2D> locations;
  
  /**
   * Explicit value constructor.
   *
   *@param locations of content.
   *@param images to put.
   */
  public WeatherDatumContentFactory(final Map<String, 
      Point2D> locations, final Map<String, Image> images)
  {
    this.images = images;
    this.locations = locations;
  }
  
  /**
   * Create content based on given datum and color.
   *
   *@param datum to use.
   *@param color of the content.
   *@return new content.
   */
  public WeatherDatumContent createContent(final WeatherDatum datum, final Color color)
  {
    return new WeatherDatumContent(datum, color, images.get(datum.getCondition()),
        locations.get(datum.getLocation()));
  }
}
