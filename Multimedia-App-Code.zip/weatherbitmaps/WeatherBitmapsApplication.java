package weatherbitmaps;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import app.JApplication;
import io.ResourceFinder;
import weather.WeatherObserver;
import weather.io.WeatherDatumReader;
import weather.io.WeatherForecastReader;
import weather.io.WeatherObservationReader;

/**
* WeatherBitmaps application.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/12/2023 
*/

public abstract class WeatherBitmapsApplication extends JApplication  implements ActionListener
{
  
  public static final int WIDTH = 600;
  public static final int HEIGHT = 800;
  protected static final String ABOUT = "About";
  protected static final String LOAD = "Load";
  private static final String F = "for";
  private static final String O = "obs";
  protected JTextField fileField;
  
  private JButton aboutButton;
  private JButton loadButton;
  private String aboutText;
  
  /**
   * Value constructor for WeatherBitmapsApplication.
   *
   *@param args command-line arguments
   */
  public WeatherBitmapsApplication(final String[] args)
  {
    super(args,WIDTH,HEIGHT);
    aboutText = "";
    fileField = new JTextField("");
    // TODO Auto-generated constructor stub
  }

  @Override
  public void actionPerformed(final ActionEvent e)
  {
    String actionCommand;
    
    actionCommand = e.getActionCommand();
    if (actionCommand.equals(ABOUT))
    {
      aboutText = "";
      handleAbout();
    } else if (actionCommand.equals(LOAD))
    {
      handleLoad();
    }

    
  }
  
  /**
   * returns the "main" JComponent.
   *
   *@return main GUI component.
   */
  protected abstract JComponent getGUIComponent();
  
  /**
   * returns the WeatherObserver that becomes
   * the observer of the WeatherSubject.
   *
   *@return weather observer object.
   */
  protected abstract WeatherObserver getWeatherObserver();
  
  /**
   * invokes the showMessageDialog() method in the JOptionPane class,
   * passing it the text contained in about.txt.
   *
   */
  protected void handleAbout()
  {
    ResourceFinder rf = ResourceFinder.createInstance(new resources.Marker());
    InputStream is = rf.findInputStream("about.txt");
    BufferedReader in = new BufferedReader(new InputStreamReader(is));
    Scanner myReader = new Scanner(in);
    while (myReader.hasNextLine())
    {
      aboutText = aboutText + myReader.nextLine() + "\n";
    }
    myReader.close();
    JOptionPane.showMessageDialog(null, aboutText);
  }
  
  /**
   * constructs the appropriate kind of WeatherDatumReader based on the file 
   * type.
   *
   */
  protected void handleLoad()
  {
    WeatherDatumReader reads = null;
    //need to get ".obs part of file"
    String fileName = fileField.getText();
    //System.out.println(fileName);
    int i = fileName.lastIndexOf('.');
    String ext = fileName.substring(i+1);
    
    if (fileName.equals(""))
    {
      JOptionPane.showMessageDialog(null, "Please input FileName.");
      return;
    }

    if (!ext.equals(F) && !ext.equals(O))
    {
      JOptionPane.showMessageDialog(null, "Invalid file name.");
      return;
    }

    try (BufferedReader reader = new BufferedReader(new FileReader(fileName)))
    {
      if (ext.equals(F))
      {
        reads = new WeatherForecastReader(reader);
      } else if (ext.equals(O))
      {
        reads = new WeatherObservationReader(reader);
        
      }
      
      if (reads.equals(null)) 
      {
        JOptionPane.showMessageDialog(null, "No file read.");
        return;
      }
      WeatherObserver obs = getWeatherObserver();
      obs.reset();
      reads.addObserver(obs);
      reads.readAll();
      
    } catch (IOException e)
    {
      JOptionPane.showMessageDialog(null, "Failed to open input file.");
    }
    //read file based on .for or .obs extension.
  }
  
  /**
   * constructs the GUI components and lays them out.
   *
   */
  public void init()
  {
    //Initialize components
    //JFrame window  = new JFrame("TextApplication");
    JRootPane window = getRootPane();
    aboutButton =  new JButton(ABOUT);
    loadButton = new JButton(LOAD);
    JTextArea file = new JTextArea("File :");
    JComponent wb = getGUIComponent();
   
    //Size window and get pane.
    window.setSize(WIDTH, HEIGHT);
    //window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JPanel contentPane = (JPanel)window.getContentPane();
    contentPane.setLayout(null);
    
    //Layout components
    aboutButton.setBounds(350,100,75,27);
    loadButton.setBounds(250,100,75,27);
    fileField.setBounds(100, 100, 125, 25);
    file.setBounds(50, 100, 125, 50);
    wb.setBounds(1, 135, 600, 665);
    
    //Add to pane and finish layout
    contentPane.add(fileField);
    contentPane.add(aboutButton);
    contentPane.add(loadButton);
    contentPane.add(file);
    contentPane.add(wb);
    aboutButton.addActionListener(this);
    loadButton.addActionListener(this);
    file.setEditable(false);
    file.setOpaque(false);
    window.setVisible(true);
  }
  
}
