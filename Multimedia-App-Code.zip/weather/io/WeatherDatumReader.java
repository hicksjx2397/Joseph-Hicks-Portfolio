package weather.io;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.IOException;
import java.util.List;

import weather.WeatherDatum;
import weather.WeatherObserver;
import weather.WeatherSubject;

/**
* Encapsulation of a WeatherDatumReader" object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   1/31/2023 
*/
public abstract class WeatherDatumReader implements WeatherSubject
{
  protected BufferedReader reader;
  protected List<WeatherObserver> observers;
  
  /**
   * Default Constructor.
   * 
   * @param reader file to read strings from.
   */
  public WeatherDatumReader(final BufferedReader reader)
  {
    this.reader = reader;
    this.observers = new ArrayList<WeatherObserver>();
  }
  
  @Override
  public void addObserver(final WeatherObserver observer)
  {
    observers.add(observer);
    
  }

  @Override
  public void notifyObservers(final WeatherDatum weather)
  {
    Iterator<WeatherObserver> i;
    WeatherObserver observer;
    i = observers.iterator();
    while (i.hasNext())
    {
      observer = i.next();
      observer.handleWeatherDatum(weather);
    }
    
  }

  @Override
  public void removeObserver(final WeatherObserver observer)
  {
    observers.remove(observer);
    
  }
  
  /**
   * Creates in a "WeatherDatum" object from the string given in reader.
   * 
   * @return created object.
   */
  protected abstract WeatherDatum readWeatherDatum() throws IOException;
  
  /**
   * Reads in one "WeatherDatum" object and notifies all observers.
   * 
   */
  public void readOne() throws IOException
  {
    WeatherDatum dat = readWeatherDatum();
    if (dat != null)
    {
      notifyObservers(dat);
    }
  }
  
  /**
   * Reads in all "WeatherDatum" objects and notifies all observers.
   * 
   */
  public void readAll() throws IOException
  {
    while (this.reader.ready())
    {
      readOne();
    }
  }
}
