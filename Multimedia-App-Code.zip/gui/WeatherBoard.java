package gui;

import weather.WeatherDatum;
import weather.WeatherObserver;
import javax.swing.JTextArea;

/**
* gui component for weather application.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/12/2023 
*/

public class WeatherBoard extends JTextArea implements WeatherObserver
{
  
  private static final long serialVersionUID = 1L;
  
  /**
   * Default constructor for WeatherBoard object.
   *
   */
  public WeatherBoard()
  {
    super();
  }

  @Override
  public void reset()
  {
    // TODO Auto-generated method stub
    this.setText("");
  }

  @Override
  public void handleWeatherDatum(final WeatherDatum datum)
  {
    if (datum != null)
    {
      this.append(datum.toString(true) + "\n");
    }
    
    // TODO Auto-generated method stub
    
  }

}
