package weatherbitmaps;

import javax.swing.JComponent;

import app.JApplication;
import gui.StaticWeatherMap;
import weather.WeatherObserver;

/**
* ApplicationRunner.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/22/2023 
*/
public class StaticMapApplication extends WeatherBitmapsApplication
{

  StaticWeatherMap weatherMap;
  
  /**
   * Value constructor for StaticMapApplication.
   *
   *@param args command-line arguments
   */
  public StaticMapApplication(final String[] args)
  {
    super(args);
    if (args.length == 0)
    {
      this.weatherMap = new StaticWeatherMap(null, null, WIDTH, HEIGHT - 100);
    } else if (args.length == 1)
    {
      this.weatherMap = new StaticWeatherMap(args[0], null, WIDTH, HEIGHT - 100);
    } else
    {
      this.weatherMap = new StaticWeatherMap(args[0], args[1], WIDTH, HEIGHT - 100);
    }
    // TODO Auto-generated constructor stub
  }
  @Override
  protected JComponent getGUIComponent()
  {
    // TODO Auto-generated method stub
    return this.weatherMap.getView();
   
  }
  @Override
  protected WeatherObserver getWeatherObserver()
  {
    // TODO Auto-generated method stub
    return this.weatherMap;
  }

  /**
   * Main method for running app.
   *
   *@param args command-line arguments
   */
  public static void main(final String[] args)
  {
    JApplication app = new StaticMapApplication(args);
    invokeInEventDispatchThread(app);
    
  }
}
