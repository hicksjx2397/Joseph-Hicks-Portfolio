package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import measurement.Scale;
import measurement.Temperature;
import weather.WeatherDatum;
import weather.WeatherForecast;

class TestWeatherForecast
{
  
  @Test
  void defaultConstructor() 
  {
    final String defaultTemp = "  +0.0F";
    WeatherForecast fore  = new WeatherForecast();
    assertEquals("XXX", fore.getLocation(),
        "get location");
    assertEquals("Unknown", fore.getCondition(),
        "get condition");
    assertEquals(defaultTemp, fore.getHigh().toString(),
        "get high");
    assertEquals(defaultTemp, fore.getLow().toString(),
        "get low");
    
  }
  
  @Test
  void valuesConstructor() 
  {
    Temperature t1 = new Temperature(45.9);
    Temperature t2 = new Temperature(58.2);
    WeatherForecast fore  = new WeatherForecast("Virginia", "Cloudy", t1, t2);
    assertEquals("Virginia,Cloudy, +45.9F, +58.2F", fore.toString(false),
        "Check valued constructor or toString()");
  }
  

  @Test
  void toStringVerbose() 
  {
    WeatherForecast fore  = 
        new WeatherForecast("PWW02", "Sunny", new Temperature(86.7), new Temperature(91.3));
    assertEquals("Location: PWW02\tCondition: Sunny\tLow:  +86.7F\tHigh:  +91.3F",
        fore.toString(true), "toString(true)");
  }
  
  @Test
  void fromStringValid() 
  {
    WeatherForecast fore  = new WeatherForecast();
    fore.fromString("Virginia,Sunny, +45.9F, +58.2F");
    assertEquals("Location: Virginia\tCondition: Sunny\tLow:  +45.9F\tHigh:  +58.2F",
        fore.toString(true), "fromString");
  }
  
  @Test
  void fromStringInvalid() 
  {
    WeatherForecast fore  = new WeatherForecast();
    WeatherForecast foreOne  = new WeatherForecast();
    assertEquals(null, fore.fromString(""));
    assertEquals(null, fore.fromString("California,"));
    assertEquals(null, fore.fromString("Virginia,Sunny"));
    assertEquals(null, foreOne.fromString("Virginia,Sunny, +67.9F"));
    
    assertEquals("Location: Virginia\tCondition: Sunny\tLow:   +0.0F\tHigh:   +0.0F",
        fore.toString(true), "fromString no temps");
    assertEquals("Location: Virginia\tCondition: Sunny\tLow:  +67.9F\tHigh:   +0.0F",
        foreOne.toString(true), "fromString one temp");
    fore.fromString("Virginia,Sunny, +45.9F, +5A.2F");
    assertEquals("Location: Virginia\tCondition: Sunny\tLow:  +45.9F\tHigh:   +0.0F",
        fore.toString(true), "fromString invalid temp");
  }
  
  @Test
  void parseWeatherForecast() 
  {
    WeatherForecast fore  = WeatherForecast.parseWeatherForecast("Texas,Rainy,  -5.0F, +22.4F");
    assertEquals("Location: Texas\tCondition: Rainy\tLow:   -5.0F\tHigh:  +22.4F",
        fore.toString(true), "ParseWeatherForecast");
  }

}
