package weather.visual;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Shape;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.Point2D;

import visual.statik.SimpleContent;
import weather.WeatherDatum;

/**
* Content object.
*
* @author  Joseph Hicks
* @version 1.0
* @since   2/22/2023 
*/
public class WeatherDatumContent implements SimpleContent
{
  protected Color color;
  protected Image image;
  protected Point2D location;
  protected WeatherDatum datum;
  //can create local variables.
  
  /**
   * Explicit value constructor.
   *
   *@param datum to use
   *@param color of the content
   *@param image of content
   *@param location to place content
   */
  public WeatherDatumContent(final WeatherDatum datum,
      final Color color, final Image image, final Point2D location)
  {
    this.datum = datum;
    this.color = color;
    this.image = image;
    this.location = location;
    
  }

  @Override
  public void render(final Graphics arg0)
  {
    
   
    Font font = new Font("Arial", Font.PLAIN,10);
    Graphics2D g2;
   
    // Cast the rendering engine appropriately
    g2 = (Graphics2D)arg0;
    FontRenderContext frc = g2.getFontRenderContext();
    GlyphVector glyphs =  font.createGlyphVector(frc, datum.toString());
    // Render the image
    image = image.getScaledInstance(30, 20, Image.SCALE_DEFAULT);
    g2.drawImage(image, // The Image to render
        (int) location.getX() - (image.getWidth(null) / 2), // The horizontal coordinate
        (int) location.getY() - (image.getHeight(null) / 2), // The vertical coordinate
        null); // An ImageObserver
    Shape shape = glyphs.getOutline((float) location.getX() - (image.getWidth(null) * 2),
        (float) location.getY() + image.getHeight(null));
    g2.setColor(color);
    g2.draw(shape);
    
  }

}
